package BUSTATION;

abstract class Worker implements Runnable {
	
	public void run() {	
	}

} //Worker
